import sys, os
from random import shuffle

f = open(sys.argv[1], 'r')

state = 'none'
question = []
answer = []
Q = []

for l in f:
  line = l.strip()
  if line == '':
    if state == 'question':
      state = 'answer'
    elif state != 'none':
      Q.append(('\n'.join(question), answer))
      state = 'none'
  elif state == 'answer':
    if line[0] == '.':
      answer.append((line[1:], 1))
    else:
      answer.append((line, 0))
  elif state == 'question':
    question.append(line)
  elif line[0].isdigit():
    state = 'question'
    question = [line]
    answer = []

f.close()

print len(Q)

while True:
  shuffle(Q)
  for q in Q:
    os.system('clear')
    print q[0]
    print ''
    for l in q[1]:
      print l[0]
    raw_input()
    for l in q[1]:
      if l[1] == 1:
	print '--- >', l[0]
    raw_input()

