pitanja bez ponudjenih: oor1.txt, oor2.txt, oor3.txt, oor4.txt
pokretanje (npr.):
  python basic.py oor1.txt

pitanja s ponudjenim: oor_p.txt, oor_p2.txt
pokretanje (npr.):
  python mc.py oor_p.txt
