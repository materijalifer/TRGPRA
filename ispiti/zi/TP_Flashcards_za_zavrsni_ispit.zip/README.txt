Hrvatski znakovi uključeni
pokretanje (npr.):
  python basic.py pitanja_zi_hr.txt