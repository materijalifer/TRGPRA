pokretanje (npr.):
  python basic.py trgpra1.txt
